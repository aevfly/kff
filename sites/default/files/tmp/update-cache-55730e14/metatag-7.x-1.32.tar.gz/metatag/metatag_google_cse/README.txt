Metatag: Google Custom Search Engine (CSE)
------------------------------------------
This module adds certain meta tags that are primarily used by Google's Custom
Search Engine aka "CSE".

The following meta tags are provided:
* thumbnail
* department
* audience
* doc_status
* rating


Credits
------------------------------------------------------------------------------
The initial development was by Carlos E Basqueira [3].


References
------------------------------------------------------------------------------
1: https://www.dublincore.org/documents/dces/
2: https://www.drupal.org/u/cebasqueira
